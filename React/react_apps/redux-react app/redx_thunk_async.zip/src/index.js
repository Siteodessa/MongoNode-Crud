import registerServiceWorker from './registerServiceWorker';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware  } from 'redux';
import App from './App';
import css from './css/z.css';
import bootstrap from './css/bootstrap.min.css';
import './App.css';
import reducer from './reducers'
import { composeWithDevTools} from 'redux-devtools-extension';
import thunk from 'redux-thunk';

const store = createStore(reducer, composeWithDevTools(applyMiddleware(thunk)));

store.subscribe(() => {
  console.log('subscribe', store.getState());
})

ReactDOM.render(
  <Provider store={store}>
  <App />
   </Provider>, document.getElementById('root'));
registerServiceWorker();
