import React, { Component } from 'react';
import { Menu } from './Menu';

export default class About extends Component {
  render() {
    return (
      <div>
        <Menu />
      <div> Welcome to page ./About </div>
      </div>
    )
  }
}
