import React from 'react';


const Track = () => <div>Tracko</div>

export default Track
