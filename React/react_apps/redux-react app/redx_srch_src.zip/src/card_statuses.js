let card_statuses = {
    "Срочное"  : "small-box bg-red",
    "Важное"   : "small-box bg-orange",
    "Нужное"   : "small-box bg-yellow",
    "Готовое"  : "small-box bg-green",
    "Ожидание" : "small-box bg-purple"
}

export default card_statuses
