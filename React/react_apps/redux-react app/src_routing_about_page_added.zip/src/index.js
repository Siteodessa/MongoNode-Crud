import registerServiceWorker from './registerServiceWorker';

import css from './css/z.css';
import bootstrap from './css/bootstrap.min.css';
import './App.css';

import { createStore, applyMiddleware  } from 'redux';
import reducer from './reducers'
import { composeWithDevTools} from 'redux-devtools-extension';
import thunk from 'redux-thunk';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import App from './App';
import About from './About';
// import {  } from 'react-router';
import { Router, Route , HashRouter, Link  } from 'react-router-dom';

const store = createStore(reducer, composeWithDevTools(applyMiddleware(thunk)));

store.subscribe(() => {
  console.log('subscribe', store.getState());
})

ReactDOM.render(
      <Provider store={store}>
        <HashRouter>
        <div>
        <Route exact path="/" component={App} />
        <Route path="/about" component={About} />
        </div>
        </HashRouter>
      </Provider>,
      document.getElementById('root'));
registerServiceWorker();
