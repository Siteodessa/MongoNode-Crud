import React, { Component } from 'react';
import { connect } from 'react-redux';
import { getTracks } from './actions/tracks';
import { Menu } from './Menu';



class App extends Component{
  constructor(props) {
    super(props);
  }
  addTrack(){
    console.log('addTrack', this.trackInput.value);
    this.props.onAddTrack(this.trackInput.value);
    this.trackInput.value= ''
  }
  findTrack(){
    console.log('findTrack', this.searchInput.value);
    this.props.onFindTrack(this.searchInput.value);
    // this.props.onAddTrack(this.trackInput.value);
    // this.trackInput.value= ''
  }
    render() {
      console.log(this.props.tracks);
      return (
      <div className="Cards">
      <div>
        <Menu />
      </div>
      <div>
        <input type="text" ref={(input) => { this.trackInput = input}} />
        <button classN ame="addTrack" onClick= {this.addTrack.bind(this)}> Add track</button>
      </div>
      <div>
        <input type="text" ref={(input) => { this.searchInput = input}} />
        <button className="addTrack" onClick={this.findTrack.bind(this)}> Find track</button>
      </div>
      <div>
        <button onClick={this.props.onGetTracks}>Get tracks</button>
      </div>
      <ul>
      {this.props.tracks.map((track, index) =>
          <div key={index}>
            <div className="col-lg-3 col-xs-6">
              <div>
                <div className="inner">
                  <h3>{}</h3>
                  <p>{}</p>
                  <p>{}</p>
                  <blockquote>{}</blockquote>
                  <span>{}</span>
                  <div className="track">{track.name}</div>
                </div>
                <div className="icon">
                  <i className="ion ion-edit"></i>
                </div>
              </div>
            </div>
          </div>
      )}
      </ul>
      </div>
    )
  }
}
export default connect(
  state => ({
    tracks: state.tracks.filter(track => track.name.includes(state.filterTracks))
  }),
  dispatch => ({
    onAddTrack: (name) => {
      const payload = {
        id: Date.now().toString(),
        name
      };
      dispatch({ type: 'ADD_TRACK', payload})
    },
    onFindTrack : (name) => {
      console.log('name', name);
      dispatch({ type: 'FIND_TRACK', payload: name})
    },
    onGetTracks: () => {
        dispatch(getTracks())
    }
  }),
)(App);
// <li key={index}>{track}</li>
      // <div className={card_statuses[card.task_status]}>
          // <h3>{i}</h3>
          // <p>{card.id}</p>
          // <p>{card.task}</p>
          // <blockquote>{card.task_desc}</blockquote>
          // <span>{card.task_status}</span>
